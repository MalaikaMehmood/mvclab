/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.newpackage;

import modifiedmvcexample.mvc.controller.newpackage.carController;
import modifiedmvcexample.mvc.view.carView;


public class main {
   // Main.java

    public static void main(String[] args) {
       
        carView view = new carView();

        carController controller = new carController(view);

        // Display the initial car list
        controller.updateView();

        // Add a new car
        controller.addCar("Chevrolet", "Impala", 2022);

        // Display the updated car list
        System.out.println("\nAfter adding a new car:");
        controller.updateView();

        // Reset the car list
        controller.resetCarList();

        // Display the car list after reset
        System.out.println("\nAfter resetting the car list:");
        controller.updateView();
    }
} 

