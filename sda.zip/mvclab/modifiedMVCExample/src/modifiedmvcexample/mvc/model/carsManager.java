/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modifiedmvcexample.mvc.model;
import modifiedmvcexample.mvc.model.Car;
import java.util.List;
/**
 *
 * @author FA22-BSE-029
 */
public class carsManager {
   public void displayHighestRankingCar(List<Car> cars) {
        if (cars == null || cars.isEmpty()) {
            System.out.println("No cars available.");
            return;
        }

        Car highestRankingCar = cars.get(0); // Start with the first car

        // Find the car with the highest year
        for (Car care : cars) {
            if (care.getYear() > highestRankingCar.getYear()) 
            {
                highestRankingCar = care;
            }
        }

        System.out.println("Highest Ranking Car:");
        System.out.println(highestRankingCar.getInfo());
    }
} 

