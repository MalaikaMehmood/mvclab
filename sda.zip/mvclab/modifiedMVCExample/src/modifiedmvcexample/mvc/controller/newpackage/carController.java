/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modifiedmvcexample.mvc.controller.newpackage;
import modifiedmvcexample.mvc.view.carView;
import java.util.ArrayList;
import java.util.List;
import model.mvc.Car;
/**
 *
 * @author FA22-BSE-029
 */
public class carController {
    private List<Car> cars;
    private carView view;

    public carController(carView view) {
        this.view = view;
        this.cars = new ArrayList<>();
        // Sample data
        cars.add(new Car("Toyota", "Camry", 2020));
        cars.add(new Car("Honda", "Civic", 2019));
        cars.add(new Car("Ford", "Mustang", 2021));
    }

   
    public void updateView() {
        view.displayCars(cars);
    }

    public void addCar(String make, String model, int year) {
        cars.add(new Car(make, model, year));
    }

    public void resetCarList() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
} 

