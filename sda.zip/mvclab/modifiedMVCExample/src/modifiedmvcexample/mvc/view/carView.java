/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modifiedmvcexample.mvc.view;
import java.util.List;
/**
 *
 * @author fa22-bse-029
 */
public class carView {

    void displayCars(List<car> cars) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    // CarView.java

public class CarView {
    public void displayCars(List<car> cars) {
        System.out.println("Car List:");
        for (car care : cars) {
            System.out.println(care.getInfo());
        }
    }
}
}
