/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modifiedmvcexample;

import modifiedmvcexample.mvc.controller.newpackage.carController;
import modifiedmvcexample.mvc.view.carView;

/**
 *
 * @author FA22-BSE-029
 */
public class ModifiedMVCExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         
        carView view = new carView();

        carController controller = new carController(view);

        // Display the initial car list
        controller.updateView();

        // Add a new car
        controller.addCar("Chevrolet", "Impala", 2022);

        // Display the updated car list
        System.out.println("\nAfter adding a new car:");
        controller.updateView();

        // Reset the car list
        controller.resetCarList();

        // Display the car list after reset
        System.out.println("\nAfter resetting the car list:");
        controller.updateView();
    }
    
}
